import java.util.Comparator;

public class SortByScore implements Comparator<Course> {

	@Override
	public int compare(Course o1, Course o2) {
		// TODO Auto-generated method stub
		return (int) (o2.getScore() - o1.getScore());
	}
	
	public SortByScore(){
		super();
	}
}
