import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.table.TableColumn;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class MainGUI {

	private JFrame frame;
	private JTextField textField;
	private String path = "Myscore.html";
	private File source,destination;
	private ArrayList<Course>  courses;
	private boolean flag = true;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainGUI window = new MainGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("\u7EE9\u70B9\u8BA1\u7B97\u5668");
		frame.setBounds(100, 100, 636, 419);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u8BF7\u8F93\u5165html\u6240\u5728\u7684\u8DEF\u5F84");
		lblNewLabel.setBounds(70, 36, 160, 18);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField(path);
		textField.setBounds(70, 67, 369, 24);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblWeight = new JLabel("\u52A0\u6743\u5E73\u5747\u5206=");
		lblWeight.setBounds(138, 184, 353, 18);
		frame.getContentPane().add(lblWeight);
		
		JLabel lblGPA = new JLabel("GPA=");
		lblGPA.setBounds(138, 240, 353, 18);
		frame.getContentPane().add(lblGPA);
		
		
		//���밴ť
		JButton button = new JButton("\u8BFB\u53D6");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				path = textField.getText().trim();
				
				source = new File(path);
				
				if(!source.exists()){
					//����������·��
					lblNewLabel.setText("������html���ڵ�·��");
					JOptionPane.showMessageDialog(frame, "·���Ƿ�������������" ,"����" , JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				courses = ProcessData.Input(source);
				if(courses != null) 
					lblNewLabel.setText("��ȡ�ɹ�");
				else 
					JOptionPane.showMessageDialog(frame, "��ȡʧ��" ,"����" , JOptionPane.ERROR_MESSAGE);
			}
		});
		button.setBounds(466, 66, 113, 27);
		frame.getContentPane().add(button);
		
	
		
		//���㰴ť
		JButton btnCalc = new JButton("\u8BA1\u7B97\u5E76\u6392\u5E8F");
		btnCalc.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(courses == null || courses.isEmpty()){
					JOptionPane.showMessageDialog(frame, "����ʧ�ܣ���������ȷ��·�������¶���" , "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				ProcessData.sort(courses);//����
				double fen[] = ProcessData.Calc(courses);
				if(flag){
					lblWeight.setText(lblWeight.getText()+Double.toString(fen[0]));
					lblGPA.setText(lblGPA.getText()+Double.toString(fen[1]));
					flag = false;
				}
				
			}
		});
		btnCalc.setBounds(70, 133, 113, 27);
		frame.getContentPane().add(btnCalc);
		
		
		
		
		//�����ť
		JButton btnOutput = new JButton("\u8F93\u51FA");
		btnOutput.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				destination = new File("Myscores.xls");
				if(courses == null || courses.isEmpty()){
					JOptionPane.showMessageDialog(frame, "���ʧ�ܣ���ȷ���Ѷ�������" , "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				if(!ProcessData.Output(courses, destination))
					JOptionPane.showMessageDialog(frame, "���ʧ��,Ҳ�����ļ����ڱ𴦴�" , "����", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnOutput.setBounds(466, 302, 113, 27);
		frame.getContentPane().add(btnOutput);
		
		
		

	}
}
