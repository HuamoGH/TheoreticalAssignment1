/*****************************************************************
 ͨ��Jsoup����myTranscript.html�� �ѵõ������ݰ��ɼ�������������Excel��
 ͬʱ�����Ȩƽ���ֺ�GPA����ȡ�����㷨���������ͬ������Excel�� 
 *****************************************************************/
package assignment2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class TranscriptExtension {

	private int headerLength = 11;
	
	private int courseNumber;	
	private String[] transcriptHeader;
	private String[] allCourseId;
	private String[] allCourseName;
	private String[] allCourseType;
	private double[] allCourseCredits;
	private String[] allCourseTeacher;
	private String[] allCourseSchool;
	private String[] allCourseLearningType;
	private int[] allCourseYear;
	private String[] allCourseTerm;
	private double[] allCourseScore;
	private String[] allCourseOperation;
	
	private double weightedAverageScore;
	private double overallGpa;

	// constructor
	public TranscriptExtension(String htmlPath) {
		
		
		// read myTranscript.html
		File mytranscript = new File(htmlPath);
		Document doc = null;
		try {
			doc = Jsoup.parse(mytranscript,"gb2312");
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		// get header
		transcriptHeader = new String[headerLength];
		Element tr1 = doc.getElementsByTag("tr").get(0);
		for (int i = 0; i < headerLength; i++){
			String th = tr1.getElementsByTag("th").get(i).toString();
			int beginIndex = th.indexOf(">")+1;
			int endIndex = th.lastIndexOf("<");
			String headerName = th.substring(beginIndex, endIndex);
			transcriptHeader[i] = headerName;
		}
		

		// get the number of all courses
		courseNumber = 0;
		do {
			Element tr = doc.getElementsByTag("tr").get(courseNumber+1);
			String td = tr.getElementsByTag("td").get(9).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			if (beginIndex == endIndex)
				break;
			courseNumber++;
		} while(true);
		
		// get id of all courses
		allCourseId = new String[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(0).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			String courseId = td.substring(beginIndex, endIndex);
			allCourseId[i-1] = courseId;
		}
		
		// get names of all courses
		allCourseName = new String[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(1).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			String courseName = td.substring(beginIndex, endIndex);
			allCourseName[i-1] = courseName;
		}
		
		// get type of all courses
		allCourseType = new String[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(2).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			String courseType = td.substring(beginIndex, endIndex);
			allCourseType[i-1] = courseType;
		}
		
		// get credits of all courses
		allCourseCredits = new double[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(3).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			double courseCredits = Double.parseDouble(td.substring(beginIndex, endIndex));
			allCourseCredits[i-1] = courseCredits;
		}
		
		// get teacher's name of all courses
		allCourseTeacher = new String[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(4).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			String courseTeacher = td.substring(beginIndex, endIndex);
			allCourseTeacher[i-1] = courseTeacher;
		}

		// get school's name of all courses
		allCourseSchool = new String[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(5).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			String courseSchool = td.substring(beginIndex, endIndex);
			allCourseSchool[i-1] = courseSchool;
		}
		
		// get learning type of all courses
		allCourseLearningType = new String[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(6).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			String courseLearningType = td.substring(beginIndex, endIndex);
			allCourseLearningType[i-1] = courseLearningType;
		}

		// get year of all courses
		allCourseYear = new int[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(7).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			String courseYear = td.substring(beginIndex, endIndex);
			allCourseYear[i-1] = Integer.parseInt(courseYear);
		}
		
		// get terms of all courses
		allCourseTerm = new String[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(8).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			String courseTerm = td.substring(beginIndex, endIndex);
			allCourseTerm[i-1] = courseTerm;
		}		
		
		
		// get scores of all courses
		allCourseScore = new double[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(9).toString();
			int beginIndex = td.indexOf(">")+1;
			int endIndex = td.lastIndexOf("<");
			double courseScore = Double.parseDouble(td.substring(beginIndex, endIndex));
			allCourseScore[i-1] = courseScore;
		}
		
		// get operations of all courses
		allCourseOperation = new String[courseNumber];
		for (int i=1; i<=courseNumber; i++) {
			Element tr = doc.getElementsByTag("tr").get(i);
			String td = tr.getElementsByTag("td").get(10).toString();

			int beginIndex = td.lastIndexOf("e")+3;
			int endIndex = td.lastIndexOf("\"");
			String courseOperation = td.substring(beginIndex, endIndex);
			allCourseOperation[i-1] = courseOperation;
		}
		
		// sorting
		double[] scoreCopy = allCourseScore.clone();
		double[] allCourseScoreCopy = allCourseScore.clone();
		Arrays.parallelSort(scoreCopy);
		for (int i = 0; i < courseNumber; i++)
			allCourseScore[i] = scoreCopy[courseNumber-1-i];
		
		String[] allCourseIdCopy = allCourseId.clone();
		String[] allCourseNameCopy = allCourseName.clone();
		String[] allCourseTypeCopy = allCourseType.clone();
		double[] allCourseCreditsCopy = allCourseCredits.clone();
		String[] allCourseTeacherCopy = allCourseTeacher.clone();
		String[] allCourseSchoolCopy = allCourseSchool.clone();
		String[] allCourseLearningTypeCopy = allCourseLearningType.clone();
		int[] allCourseYearCopy = allCourseYear.clone();
		String[] allCourseTermCopy = allCourseTerm.clone();
		String[] allCourseOperationCopy = allCourseOperation.clone();
		
		for (int i = 0; i < courseNumber; i++){
			for (int j = 0; j < courseNumber; j++){
				if (allCourseScoreCopy[j] == allCourseScore[i]){
					allCourseScoreCopy[j] = -1;
					allCourseId[i] = allCourseIdCopy[j];
					allCourseName[i] = allCourseNameCopy[j];
					allCourseType[i] = allCourseTypeCopy[j];
					allCourseCredits[i] = allCourseCreditsCopy[j];
					allCourseTeacher[i] = allCourseTeacherCopy[j];
					allCourseSchool[i] = allCourseSchoolCopy[j];
					allCourseLearningType[i] = allCourseLearningTypeCopy[j];
					allCourseYear[i] = allCourseYearCopy[j];
					allCourseTerm[i] = allCourseTermCopy[j];
					allCourseOperation[i] = allCourseOperationCopy[j];
					break;
				}
			}
		}
		// calculate weighted average score
		double sumCredits = 0;
		double sumScore = 0;
		for (int i = 0; i < courseNumber; i++){
			if (allCourseScore[i] >= 60){
				sumScore += allCourseCredits[i]*allCourseScore[i];
				sumCredits += allCourseCredits[i];
			}
		}
		weightedAverageScore = sumScore/sumCredits;
		
		// calculate GPA
		double sumGpa = 0;
		double[] gpa = new double[courseNumber];
		for (int i = 0; i < courseNumber; i++){
			if (allCourseScore[i] >= 90)
				gpa[i] = 4.0;
			else if (allCourseScore[i] >= 85 && allCourseScore[i] < 90)
				gpa[i] = 3.7;
			else if (allCourseScore[i] >= 82 && allCourseScore[i] < 85)
				gpa[i] = 3.3;
			else if (allCourseScore[i] >= 78 && allCourseScore[i] < 82)
				gpa[i] = 3.0;
			else if (allCourseScore[i] >= 75 && allCourseScore[i] < 78)
				gpa[i] = 2.7;
			else if (allCourseScore[i] >= 72 && allCourseScore[i] < 75)
				gpa[i] = 2.3;
			else if (allCourseScore[i] >= 68 && allCourseScore[i] < 72)
				gpa[i] = 2.0;
			else if (allCourseScore[i] >= 64 && allCourseScore[i] < 68)
				gpa[i] = 1.5;
			else if (allCourseScore[i] >= 60 && allCourseScore[i] < 64)
				gpa[i] = 1.0;
			else
				gpa[i] = 0;
		}
		for (int i = 0; i < courseNumber; i++){
			if (gpa[i] >= 1) {
				sumGpa += allCourseCredits[i]*gpa[i];
			}
		}
		overallGpa = sumGpa/sumCredits;
	}
	
	public double getWeightedAverageScore() {
		return weightedAverageScore;
	}
	
	public double getGpa() {
		return overallGpa;
	}
	
	public String getHeader(int idx) {
		return transcriptHeader[idx];
	}
	
	public void save(String filePath) {
		// create excel and set formats
		Workbook transcriptWorkbook = new XSSFWorkbook();
		XSSFCellStyle style = (XSSFCellStyle) transcriptWorkbook.createCellStyle();
		style.setAlignment(XSSFCellStyle.ALIGN_CENTER);
		
		Sheet transcriptSheet = transcriptWorkbook.createSheet("Transcript");
		transcriptSheet.setColumnWidth(0, 20*256);
		transcriptSheet.setColumnWidth(1, 40*256);
		transcriptSheet.setColumnWidth(5, 20*256);
		
		// input header
		Row rowHeader = transcriptSheet.createRow(0);
		for (short i = 0; i < headerLength; i++) 
			rowHeader.createCell(i).setCellValue(transcriptHeader[i]);
		
		// input data
		for (int i=1; i <= courseNumber; i++){
			Row row = transcriptSheet.createRow(i);
			row.createCell(0).setCellValue(allCourseId[i-1]);
			row.createCell(1).setCellValue(allCourseName[i-1]);
			row.createCell(2).setCellValue(allCourseType[i-1]);
			row.createCell(3).setCellValue(allCourseCredits[i-1]);
			row.createCell(4).setCellValue(allCourseTeacher[i-1]);
			row.createCell(5).setCellValue(allCourseSchool[i-1]);
			row.createCell(6).setCellValue(allCourseLearningType[i-1]);
			row.createCell(7).setCellValue(allCourseYear[i-1]);
			row.createCell(8).setCellValue(allCourseTerm[i-1]);
			row.createCell(9).setCellValue(allCourseScore[i-1]);
			row.createCell(10).setCellValue(allCourseOperation[i-1]);
		}
		
		// input weighted average score
		Row rowAverageScore = transcriptSheet.createRow(courseNumber+1);
		XSSFCell cellAverageScore = (XSSFCell) rowAverageScore.createCell((short)0);
		cellAverageScore.setCellValue("��Ȩƽ����");
		cellAverageScore.setCellStyle(style);
        rowAverageScore.createCell(1).setCellValue(weightedAverageScore);		

		
		// input overall GPA
		Row rowGpa = transcriptSheet.createRow(courseNumber+2);
		XSSFCell cellGpa = (XSSFCell) rowGpa.createCell((short)0);
		cellGpa.setCellValue("�ۺϼ�ȨGPA");
		cellGpa.setCellStyle(style);
        rowGpa.createCell(1).setCellValue(overallGpa);
	
		
		// Write the output to a file
	    FileOutputStream fileOut = null;
		try {
			fileOut = new FileOutputStream(filePath);
			transcriptWorkbook.write(fileOut);
			fileOut.close();
			transcriptWorkbook.close();
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	    catch (IOException e) {
	    	e.printStackTrace();
		}		
	}
}
